
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit
from pyts.datasets import load_gunpoint
import matplotlib.pyplot as plt
from pyts.transformation import ShapeletTransform

data = np.genfromtxt('BinaryHeartbeat.csv', delimiter=',')
# data2 = pd.read_csv('BinaryHeartbeat.csv')


X = pd.read_csv("BinaryHeartbeat.csv")
y = X['target']


sss = StratifiedShuffleSplit(n_splits=2, test_size=0.5, random_state=0)
sss.get_n_splits(X, y)

X.drop(columns='target', inplace=True)
# print(X)

for train_index, test_index in sss.split(X, y):
    # print("TRAIN:", train_index, "TEST:", test_index)
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]


# X_train = np.empty(409,np.ndarray)
# y_train = np.empty(409, int)


# i = 0
# k = 0
# while i < 409:
#     i += 1
#     if i < 299:
#         y_train[k] = 2
#         k += 1
#     if i >= 299:
#         y_train[k] = 1
#         k += 1
    

# i = 0
# k = 0
# while i < 409:
#     i += 1
#     X_train[k] = data[i,1:18531]
#     k += 1


# print(X_train)
# print(data[1,1:18531][0])

# print("---This-is-my-data---")
# print('type of X')
# print(type(X))
# print('type of X[0]')
# print(type(X[0]))
# print('type of X[0][0]')
# print(type(X[0][0]))
# i = 0
# while i < 299:


# Toy dataset
# X_train, _, y_train, _ = load_gunpoint(return_X_y=True)
# print('---This-is-provided-data---')
# print('type of X_train')
# print(type(X_train))
# print('type of X_train[0]')
# print(type(X_train[0]))
# print('type of X_train[0][0]')
# print(type(X_train[0][0]))


# plt.plot(X_axis, y1, linestyle='-', color='red', linewidth=1, label='abnormal')
# plt.plot(X_axis, y2, linestyle='-', color='green', linewidth=0.5, label ='normal')
# plt.ylim(2,-2)
# plt.xlabel('Time')
# plt.title('Normal vs Abnormal Heartbeat')
# plt.ylabel('Signal')
# plt.legend()
# plt.savefig('Normal_vs_Abnormal.pdf', format='pdf', bbox_inches='tight')



# # Shapelet transformation
st = ShapeletTransform(window_sizes=[12, 24, 36, 48],
                       random_state=42, sort=True)
print("Here")
X_new = st.fit_transform(X_train, y_train)

# Visualize the four most discriminative shapelets
plt.figure(figsize=(6, 4))
for i, index in enumerate(st.indices_[:4]):
    idx, start, end = index
    plt.plot(X_train[idx], color='C{}'.format(i),
             label='Sample {}'.format(idx))
    plt.plot(np.arange(start, end), X_train[idx, start:end],
             lw=5, color='C{}'.format(i))

plt.xlabel('Time', fontsize=12)
plt.title('The four more discriminative shapelets', fontsize=14)
plt.legend(loc='best', fontsize=8)
plt.show()

