import numpy as np
import pandas as pd
from collections import Counter
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import accuracy_score
from scipy.spatial import distance
import matplotlib.pyplot as plt

data = pd.read_csv('sample_data/BinaryHeartbeat.csv')

X= data[data.columns[:-1]]
y= data['Target']

# We will be using the scikit learn library StratifiedShuffleSplit function for splitting the data set
#test_size : should be between 0.0 and 1.0 and represent the proportion of the dataset to include in the test split.

sss = StratifiedShuffleSplit(n_splits=1, test_size=0.5, random_state=0)
sss.get_n_splits(X, y)
for train_index, test_index in sss.split(X, y):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]


def most_frequent(List):
    freq = Counter(List)
    return freq.most_common(1)[0][0]

def get_distVector(timeSeries):
    dist_lst= []

    for i in range(X_train.shape[0]):
      dist = distance.euclidean(timeSeries, X_train[i:i + 1].values[0])
      dist_lst.append(dist)

    return dist_lst

m = get_distVector(X_train[1:2].values[0])


def get_vote(distances, k):
    votes = []
    idx = np.argpartition(distances, k)[:k] # indices of the k nearest neighbors in the time series training set matrix
    for id in idx:
      votes.append(y_train[id:id + 1].values[0])
    return most_frequent(votes)

test_accuracies = []
train_accuracies = []

for k in range(1,60,2):
    print("K = "+str(k))
    ytest_pred, ytrain_pred = [], []
    for i in range(len(y_test)):
        # Get the distance between test example i and all the time series in the training set
        distances =  get_distVector(X_test[i:i+1].values[0])
        # Get the majority voted label
        vote =  get_vote(distances, k)
        # Append the predicted vote to the predicted list of lasbels ytest_pred
        ytest_pred.append(vote)

    test_accuracies.append(accuracy_score(y_test,ytest_pred))

    for i in range(len(y_train)):
        # Get the distance between train example i and all the time series in the training set
        distances = get_distVector(X_train[i:i+1].values[0]) 
        # Get the majority voted label
        vote = get_vote(distances, k)
        # Append the predicted vote to the predicted list of lasbels ytrain_pred
        ytrain_pred.append(vote)
    train_accuracies.append(accuracy_score(y_train, ytrain_pred))

plt.plot(train_accuracies, label = "train")
plt.plot(test_accuracies, label = "test")
plt.ylim(0.8, 1.011)
plt.ylabel('Accuracy')
plt.xlabel('Number of Instances ')
plt.title('Heartbeat Classification')
plt.legend()
plt.show()